package com.snhu.sslserver;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@RestController
public class ServerController {

    @RequestMapping("/hash")
    public String myHash() {
        String data = "Sharif Ayesh - Artemis Financial Secure Data";
        String algorithm = "SHA-256";
        String checksum;

        try {
            MessageDigest md = MessageDigest.getInstance(algorithm);
            byte[] hashBytes = md.digest(data.getBytes());
            checksum = bytesToHex(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            return "<p>Error generating checksum: " + e.getMessage() + "</p>";
        }

        return "<p>Data: " + data + "</p>" +
               "<p>Checksum (SHA-256): " + checksum + "</p>";
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
